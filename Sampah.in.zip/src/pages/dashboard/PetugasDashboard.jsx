import React from 'react';

export default function PetugasDashboard() {
  return <h1>Petugas Dashboard</h1>;
}
